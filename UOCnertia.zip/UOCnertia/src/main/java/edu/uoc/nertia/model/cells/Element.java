package edu.uoc.nertia.model.cells;

public enum Element {

    EMPTY('-',"empty.png"),
    EXTRA_LIFE('L',"life.png"),
    GEM('*',"gem.png"),
    MINE('X',"mine.png"),
    PLAYER('@',"player.png"),
    STOP('S',"stop.png"),

    PLAYER_STOP('$',"player_stop.png"),
    WALL('#', "wall.png");

    private String imageSrc;
    private char symbol;

    Element (char symbol, String imageSrc){
        setImageSrc(imageSrc);
        setSymbol(symbol);
    }

    private void setSymbol(char symbol){
        this.symbol=symbol;
    }

    private void setImageSrc(String imageSrc){
        this.imageSrc=imageSrc;
    }

    public static Element symbol2Element (char symbol) {
        switch (symbol) {
            case 'L':
                return EXTRA_LIFE;
            case '*':
                return GEM;
            case 'X':
                return MINE;
            case '@':
                return PLAYER;
            case '$':
                return PLAYER_STOP;
            case 'S':
                return STOP;
            case '-':
                return EMPTY;
            case '#':
                return WALL;
            default:
                return null;

        }
    }

    public char getSymbol(){
        return this.symbol;
    }

    public String getImageSrc(){
        return this.imageSrc;
    }

    @Override
    public String toString(){
        return String.valueOf(symbol);
    }

}
