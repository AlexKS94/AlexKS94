package edu.uoc.nertia.model.utils;

import edu.uoc.nertia.model.exceptions.PositionException;

import java.lang.annotation.Inherited;
import java.util.Objects;

public class Position extends Object{
    private int column;
    private int row;

    public Position(int row, int column) throws PositionException{

        setColumn(column);
        setRow(row);
    }

    private void setRow (int row) throws PositionException{
        if(row<0){
            throw new PositionException(PositionException.POSITION_ROW_ERROR);
        }else{
            this.row=row;
        }
    }
    private void setColumn (int column) throws PositionException{
        if(column<0){
            throw new PositionException(PositionException.POSITION_COLUMN_ERROR);
        }else{
            this.column=column;
        }
    }

    public int getRow(){
        return row;
    }

    public int getColumn(){
        return column;
    }

    public Position offsetBy (int dRow, int dColumn){

        if( row+dRow<0 || column+dColumn < 0){
            return null;
        }else{
            Position newPosition= null;
            try {
                newPosition = new Position(row + dRow, column + dColumn);
            }catch (PositionException e){}
            return newPosition;
        }
    }

    public Position offsetBy(int dRow, int dColumn, int size){
        if( row+dRow<0 || column+dColumn < 0 || row+dRow>=size || column+dColumn>=size || size < 1){
            return null;
        }else{
            Position newPosition= null;
            try {
                newPosition = new Position(row + dRow, column + dColumn);
            }catch (PositionException e){}
            return newPosition;
        }
    }
    @Override
    public boolean equals(Object object){

        Position position = (Position) object;
        return this == position || (this.getColumn() == position.getColumn() && this.getRow() == position.getRow());
    }

    @Override
    public int hashCode(){
        return Objects.hash(this.getRow(), this.getColumn());
    }
}
