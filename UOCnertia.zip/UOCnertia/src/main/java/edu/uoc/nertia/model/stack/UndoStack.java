package edu.uoc.nertia.model.stack;

import java.util.Stack;

public class UndoStack extends Stack<StackItem> {

    private int numPops=0;

    public UndoStack(){
    }

    @Override
    public StackItem pop(){
        if (isEmpty()){
            return null;
        }else{
            incrementNumPops();
            return super.pop();
        }
    }

    public int getNumPops(){
        return numPops;
    }

    private void incrementNumPops(){
        numPops= numPops+1;
    }
}
