package edu.uoc.nertia.model.leaderboard;

import java.io.Serializable;
import java.util.Locale;

public record Score(String name, int points) implements Comparable<Score>, Serializable{

    private static final long serialVersionUID =13L;

    @Override
    public String toString(){
        return this.name.toUpperCase(Locale.ROOT)+" : "+ this.points+ " pts";
    }

    @Override
    public int compareTo(Score o){

      if(this.points > o.points){
            return -1;
      }else if (this.points< o.points){
          return 1;
      }else{
          return 0;
      }
    }
}
