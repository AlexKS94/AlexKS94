package edu.uoc.nertia.model.utils;

public enum MoveResult {
    DIE, KO, OK;
}
