package edu.uoc.nertia.model.levels;

public enum LevelDifficulty {
    EASY, HARD, MEDIUM;

    LevelDifficulty(){}
}
